module.exports = {
  env: {
    MONGO_URI:
      "mongodb+srv://amrit_port:122333444455555@cluster0.aq5hu.mongodb.net/portfolioDB?retryWrites=true&w=majority",
  },
  images : {
    domains : ["images.unsplash.com"],
  }
};
